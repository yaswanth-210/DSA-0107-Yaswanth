/**
 * ESPORTS C++ TOURNAMENT MANAGEMENT AND AUTOMATED RANKING SYSTEM
 * Interactive Simulation Engine
 */

// LocalStorage Keys
const STORAGE_KEY_TEAMS = "esports_cpp_teams";
const STORAGE_KEY_TOURNAMENTS = "esports_cpp_tournaments";
const STORAGE_KEY_MATCHES = "esports_cpp_matches";

// Default Initial Sample Data
const DEFAULT_TEAMS = [
  {
    id: "team_1",
    name: "Phoenix",
    game: "BGMI",
    captain: "Rahul",
    members: ["Rahul", "Aman", "Vicky", "Sameer"]
  },
  {
    id: "team_2",
    name: "Shadow X",
    game: "Valorant",
    captain: "Arjun",
    members: ["Arjun", "Rohan", "Dev", "Kabir", "Neil"]
  },
  {
    id: "team_3",
    name: "Thunder",
    game: "Free Fire",
    captain: "Kiran",
    members: ["Kiran", "Yash", "Rohit", "Aryan"]
  }
];

const DEFAULT_TOURNAMENTS = [
  { id: "tourn_1", name: "Esports Masters Cup", game: "BGMI", format: "Group Stage" },
  { id: "tourn_2", name: "Valorant Pro Invitational", game: "Valorant", format: "Knockout" },
  { id: "tourn_3", name: "Battle Royale Premier", game: "Free Fire", format: "Round-Robin" }
];

// Matches structured to produce the exact initial sample leaderboard:
// Phoenix: 3 Wins (9 pts), Shadow X: 2 Wins (6 pts), Thunder: 1 Win (3 pts)
// plus the specific sample matches requested: Match 1 (Completed), Match 2 (Upcoming), Match 3 (Upcoming)
const DEFAULT_MATCHES = [
  // Historical league matches establishing base standing
  {
    id: "match_init_1",
    label: "Placement Match A",
    tournId: "tourn_1",
    game: "BGMI",
    team1: "Phoenix",
    team2: "Shadow X",
    score1: 16,
    score2: 12,
    status: "Completed",
    winner: "Phoenix"
  },
  {
    id: "match_init_2",
    label: "Placement Match B",
    tournId: "tourn_2",
    game: "Valorant",
    team1: "Phoenix",
    team2: "Thunder",
    score1: 2,
    score2: 0,
    status: "Completed",
    winner: "Phoenix"
  },
  {
    id: "match_init_3",
    label: "Placement Match C",
    tournId: "tourn_2",
    game: "Valorant",
    team1: "Shadow X",
    team2: "Thunder",
    score1: 13,
    score2: 9,
    status: "Completed",
    winner: "Shadow X"
  },
  {
    id: "match_init_4",
    label: "Placement Match D",
    tournId: "tourn_3",
    game: "Free Fire",
    team1: "Shadow X",
    team2: "Thunder",
    score1: 15,
    score2: 11,
    status: "Completed",
    winner: "Shadow X"
  },
  {
    id: "match_init_5",
    label: "Placement Match E",
    tournId: "tourn_3",
    game: "Free Fire",
    team1: "Thunder",
    team2: "Shadow X",
    score1: 18,
    score2: 14,
    status: "Completed",
    winner: "Thunder"
  },
  // Specific demonstration matches from prompt:
  {
    id: "match_1",
    label: "Match 1",
    tournId: "tourn_1",
    game: "BGMI",
    team1: "Phoenix",
    team2: "Shadow X",
    score1: 16,
    score2: 10,
    status: "Completed",
    winner: "Phoenix"
  },
  {
    id: "match_2",
    label: "Match 2",
    tournId: "tourn_3",
    game: "Free Fire",
    team1: "Thunder",
    team2: "Phoenix",
    score1: null,
    score2: null,
    status: "Upcoming",
    winner: "Pending"
  },
  {
    id: "match_3",
    label: "Match 3",
    tournId: "tourn_2",
    game: "Valorant",
    team1: "Shadow X",
    team2: "Thunder",
    score1: null,
    score2: null,
    status: "Upcoming",
    winner: "Pending"
  }
];

// App State
let teams = [];
let tournaments = [];
let matches = [];

// Initialize or Load from LocalStorage
function initData() {
  const storedTeams = localStorage.getItem(STORAGE_KEY_TEAMS);
  const storedTournaments = localStorage.getItem(STORAGE_KEY_TOURNAMENTS);
  const storedMatches = localStorage.getItem(STORAGE_KEY_MATCHES);

  if (storedTeams && storedTournaments && storedMatches) {
    try {
      teams = JSON.parse(storedTeams);
      tournaments = JSON.parse(storedTournaments);
      matches = JSON.parse(storedMatches);
    } catch (e) {
      resetToDefaultData(false);
    }
  } else {
    resetToDefaultData(false);
  }

  renderAll();
}

// Reset data back to default sample state
function resetToDefaultData(notify = true) {
  teams = JSON.parse(JSON.stringify(DEFAULT_TEAMS));
  tournaments = JSON.parse(JSON.stringify(DEFAULT_TOURNAMENTS));
  matches = JSON.parse(JSON.stringify(DEFAULT_MATCHES));
  saveAll();
  renderAll();
  if (notify) {
    showToast("Sample data reset successfully!", "success");
  }
}

// Persist data into LocalStorage
function saveAll() {
  localStorage.setItem(STORAGE_KEY_TEAMS, JSON.stringify(teams));
  localStorage.setItem(STORAGE_KEY_TOURNAMENTS, JSON.stringify(tournaments));
  localStorage.setItem(STORAGE_KEY_MATCHES, JSON.stringify(matches));
}

// Re-render everything across all modules
function renderAll() {
  renderQuickStats();
  renderTeamsTable();
  renderTournamentsShelf();
  populateMatchFormSelects();
  renderMatchesTable();
  renderLeaderboard();
}

// Toast Notifications
function showToast(message, type = "success") {
  const container = document.getElementById("toastContainer");
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${type === "success" ? "✓" : "⚠️"}</span>
    <span class="toast-msg">${message}</span>
  `;
  container.appendChild(toast);

  // Trigger animation
  requestAnimationFrame(() => {
    toast.classList.add("show");
  });

  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 300);
  }, 3200);
}

// Helper: Game pill class
function getGamePillClass(game) {
  const g = (game || "").toLowerCase().replace(/\s+/g, "");
  if (g.includes("bgmi")) return "pill-bgmi";
  if (g.includes("valorant")) return "pill-valorant";
  if (g.includes("freefire")) return "pill-freefire";
  if (g.includes("cs2")) return "pill-cs2";
  return "pill-bgmi";
}

// ==========================================
// HOME PAGE QUICK STATS
// ==========================================
function renderQuickStats() {
  const statTeams = document.getElementById("quickStatTeams");
  const statMatches = document.getElementById("quickStatMatches");
  const statLeader = document.getElementById("quickStatLeader");

  if (statTeams) statTeams.textContent = `${teams.length} Teams Registered`;
  if (statMatches) statMatches.textContent = `${matches.length} Matches in System`;

  // Determine top team from leaderboard calculation
  const standings = computeLeaderboard();
  if (standings.length > 0 && statLeader) {
    const leader = standings[0];
    statLeader.textContent = `Top: ${leader.name} (${leader.points} Pts)`;
  }
}

// ==========================================
// MODULE 1: TEAMS MANAGEMENT
// ==========================================
function renderTeamsTable() {
  const tbody = document.getElementById("teamsTableBody");
  if (!tbody) return;

  const searchQuery = (document.getElementById("searchTeamInput")?.value || "").toLowerCase().trim();
  const gameFilter = document.getElementById("filterTeamGameSelect")?.value || "ALL";

  const filteredTeams = teams.filter((t) => {
    const matchesSearch =
      t.name.toLowerCase().includes(searchQuery) ||
      t.captain.toLowerCase().includes(searchQuery);
    const matchesGame = gameFilter === "ALL" || t.game === gameFilter;
    return matchesSearch && matchesGame;
  });

  if (filteredTeams.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" style="text-align:center; padding: 28px; color: var(--text-dim);">
          No teams found matching the search/filter criteria.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filteredTeams
    .map((team, idx) => {
      const membersCount = Array.isArray(team.members) ? team.members.length : 0;
      const membersList = Array.isArray(team.members) ? team.members.join(", ") : team.captain;
      return `
        <tr>
          <td>${idx + 1}</td>
          <td class="team-badge-cell">${team.name}</td>
          <td><span class="game-pill ${getGamePillClass(team.game)}">${team.game}</span></td>
          <td><strong>${team.captain}</strong></td>
          <td>${membersCount} Players</td>
          <td style="color: var(--text-muted); font-size: 0.85rem; max-width: 250px;">${membersList}</td>
          <td>
            <div class="table-actions">
              <button class="btn-action-icon btn-action-edit" onclick="openEditTeamModal('${team.id}')" title="Edit Team">
                ✏️ Edit
              </button>
              <button class="btn-action-icon btn-action-delete" onclick="deleteTeam('${team.id}')" title="Delete Team">
                🗑️ Delete
              </button>
            </div>
          </td>
        </tr>
      `;
    })
    .join("");
}

// Open Add Team Modal
document.getElementById("openAddTeamModalBtn")?.addEventListener("click", () => {
  document.getElementById("teamModalTitle").textContent = "Register New Team";
  document.getElementById("teamForm").reset();
  document.getElementById("teamEditId").value = "";
  openModal("teamModal");
});

// Open Edit Team Modal
window.openEditTeamModal = function (teamId) {
  const team = teams.find((t) => t.id === teamId);
  if (!team) return;

  document.getElementById("teamModalTitle").textContent = "Edit Team Details";
  document.getElementById("teamEditId").value = team.id;
  document.getElementById("teamNameInput").value = team.name;
  document.getElementById("teamGameSelect").value = team.game;
  document.getElementById("teamCaptainInput").value = team.captain;
  document.getElementById("teamMembersInput").value = Array.isArray(team.members)
    ? team.members.join(", ")
    : team.captain;

  openModal("teamModal");
};

// Handle Save Team (Add or Edit)
document.getElementById("teamForm")?.addEventListener("submit", (e) => {
  e.preventDefault();
  const editId = document.getElementById("teamEditId").value;
  const name = document.getElementById("teamNameInput").value.trim();
  const game = document.getElementById("teamGameSelect").value;
  const captain = document.getElementById("teamCaptainInput").value.trim();
  const rawMembers = document.getElementById("teamMembersInput").value;

  // Parse members array
  let members = rawMembers
    .split(",")
    .map((m) => m.trim())
    .filter((m) => m.length > 0);

  // Ensure captain is included
  if (!members.includes(captain)) {
    members.unshift(captain);
  }

  if (editId) {
    // Edit existing team
    const index = teams.findIndex((t) => t.id === editId);
    if (index !== -1) {
      const oldName = teams[index].name;
      teams[index] = { ...teams[index], name, game, captain, members };

      // Also update team name in existing matches if changed
      if (oldName !== name) {
        matches.forEach((m) => {
          if (m.team1 === oldName) m.team1 = name;
          if (m.team2 === oldName) m.team2 = name;
          if (m.winner === oldName) m.winner = name;
        });
      }

      showToast(`Team "${name}" updated successfully!`, "success");
    }
  } else {
    // Add new team
    const newTeam = {
      id: "team_" + Date.now(),
      name,
      game,
      captain,
      members
    };
    teams.push(newTeam);
    showToast(`Team "${name}" registered successfully!`, "success");
  }

  saveAll();
  closeModal("teamModal");
  renderAll();
});

// Delete Team
window.deleteTeam = function (teamId) {
  const team = teams.find((t) => t.id === teamId);
  if (!team) return;

  if (confirm(`Are you sure you want to delete team "${team.name}"?`)) {
    teams = teams.filter((t) => t.id !== teamId);
    saveAll();
    renderAll();
    showToast(`Team "${team.name}" deleted.`, "danger");
  }
};

// Search & Filter event listeners for Module 1
document.getElementById("searchTeamInput")?.addEventListener("input", renderTeamsTable);
document.getElementById("filterTeamGameSelect")?.addEventListener("change", renderTeamsTable);

// ==========================================
// MODULE 2: TOURNAMENTS & MATCHES
// ==========================================
function renderTournamentsShelf() {
  const shelf = document.getElementById("tournamentsShelf");
  if (!shelf) return;

  shelf.innerHTML = tournaments
    .map((tourn) => {
      const matchCount = matches.filter((m) => m.tournId === tourn.id).length;
      return `
        <div class="tourn-card">
          <div>
            <h4>${tourn.name}</h4>
            <div class="tourn-meta">
              <span class="game-pill ${getGamePillClass(tourn.game)}">${tourn.game}</span>
              <span>• ${tourn.format || "Knockout"}</span>
              <span>• ${matchCount} Matches</span>
            </div>
          </div>
        </div>
      `;
    })
    .join("");
}

function populateMatchFormSelects() {
  const tournSelect = document.getElementById("matchTournSelect");
  const team1Select = document.getElementById("matchTeam1Select");
  const team2Select = document.getElementById("matchTeam2Select");

  if (tournSelect) {
    tournSelect.innerHTML = tournaments
      .map((t) => `<option value="${t.id}">${t.name} (${t.game})</option>`)
      .join("");
  }

  const teamOptions = teams.map((t) => `<option value="${t.name}">${t.name} (${t.game})</option>`).join("");
  if (team1Select) team1Select.innerHTML = teamOptions;
  if (team2Select) {
    team2Select.innerHTML = teamOptions;
    // Set team 2 default to second team if exists
    if (teams.length > 1) {
      team2Select.selectedIndex = 1;
    }
  }
}

// Render Matches Table
let currentMatchStatusFilter = "ALL";

function renderMatchesTable() {
  const tbody = document.getElementById("matchesTableBody");
  if (!tbody) return;

  const gameFilter = document.getElementById("filterMatchGameSelect")?.value || "ALL";

  const filteredMatches = matches.filter((m) => {
    const matchesStatus =
      currentMatchStatusFilter === "ALL" || m.status === currentMatchStatusFilter;
    const matchesGame = gameFilter === "ALL" || m.game === gameFilter;
    return matchesStatus && matchesGame;
  });

  if (filteredMatches.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="9" style="text-align:center; padding: 28px; color: var(--text-dim);">
          No matches found for the selected status/game filters.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filteredMatches
    .map((m) => {
      const tourn = tournaments.find((t) => t.id === m.tournId);
      const tournName = tourn ? tourn.name : "Tournament";
      const isCompleted = m.status === "Completed";
      const scoreText = isCompleted ? `${m.score1} - ${m.score2}` : "- vs -";
      const statusPillClass = isCompleted ? "status-completed" : "status-upcoming";
      const winnerText = isCompleted
        ? m.winner === "Draw"
          ? "🤝 Draw"
          : `🏆 ${m.winner}`
        : "Pending";

      return `
        <tr>
          <td><strong>${m.label || "Match"}</strong></td>
          <td>
            <div style="font-weight:600; color:#fff;">${tournName}</div>
            <span class="game-pill ${getGamePillClass(m.game)}">${m.game}</span>
          </td>
          <td class="team-badge-cell">${m.team1}</td>
          <td style="color: var(--neon-purple); font-weight:700;">VS</td>
          <td class="team-badge-cell">${m.team2}</td>
          <td class="score-display">${scoreText}</td>
          <td><span class="status-pill ${statusPillClass}">${m.status}</span></td>
          <td class="winner-cell">${winnerText}</td>
          <td>
            <button class="btn btn-action-score btn-sm" onclick="openScoreModal('${m.id}')">
              ${isCompleted ? "Edit Score" : "Enter Score"}
            </button>
          </td>
        </tr>
      `;
    })
    .join("");
}

// Add Tournament Modal
document.getElementById("openAddTournamentModalBtn")?.addEventListener("click", () => {
  document.getElementById("tournamentForm").reset();
  openModal("tournamentModal");
});

document.getElementById("tournamentForm")?.addEventListener("submit", (e) => {
  e.preventDefault();
  const name = document.getElementById("tournNameInput").value.trim();
  const game = document.getElementById("tournGameSelect").value;
  const format = document.getElementById("tournFormatSelect").value;

  const newTourn = {
    id: "tourn_" + Date.now(),
    name,
    game,
    format
  };

  tournaments.push(newTourn);
  saveAll();
  closeModal("tournamentModal");
  renderAll();
  showToast(`Tournament "${name}" created!`, "success");
});

// Schedule Match Modal
document.getElementById("openScheduleMatchModalBtn")?.addEventListener("click", () => {
  if (teams.length < 2) {
    showToast("Please register at least 2 teams before scheduling matches.", "danger");
    return;
  }
  populateMatchFormSelects();
  document.getElementById("scheduleForm").reset();
  openModal("scheduleModal");
});

document.getElementById("scheduleForm")?.addEventListener("submit", (e) => {
  e.preventDefault();
  const tournId = document.getElementById("matchTournSelect").value;
  const team1 = document.getElementById("matchTeam1Select").value;
  const team2 = document.getElementById("matchTeam2Select").value;
  const label = document.getElementById("matchNameInput").value.trim();

  if (team1 === team2) {
    showToast("A team cannot play against itself! Select two distinct teams.", "danger");
    return;
  }

  const tourn = tournaments.find((t) => t.id === tournId);
  const game = tourn ? tourn.game : "General";

  const newMatch = {
    id: "match_" + Date.now(),
    label: label || `Match ${matches.length + 1}`,
    tournId,
    game,
    team1,
    team2,
    score1: null,
    score2: null,
    status: "Upcoming",
    winner: "Pending"
  };

  matches.push(newMatch);
  saveAll();
  closeModal("scheduleModal");
  renderAll();
  showToast(`Match "${newMatch.label}" scheduled between ${team1} and ${team2}!`, "success");
});

// Score Entry Modal Logic
window.openScoreModal = function (matchId) {
  const match = matches.find((m) => m.id === matchId);
  if (!match) return;

  document.getElementById("scoreMatchId").value = match.id;
  document.getElementById("scoreModalMatchTitle").textContent = `${match.label || "Match"} Scoring`;
  document.getElementById("scoreModalGameInfo").textContent = `Category: ${match.game}`;
  document.getElementById("scoreTeam1Name").textContent = match.team1;
  document.getElementById("scoreTeam2Name").textContent = match.team2;

  document.getElementById("team1ScoreInput").value = match.score1 !== null ? match.score1 : "";
  document.getElementById("team2ScoreInput").value = match.score2 !== null ? match.score2 : "";

  openModal("scoreModal");
};

// Handle Score Form Submission: Automatically evaluate winner and update rankings!
document.getElementById("scoreForm")?.addEventListener("submit", (e) => {
  e.preventDefault();
  const matchId = document.getElementById("scoreMatchId").value;
  const s1 = parseInt(document.getElementById("team1ScoreInput").value, 10);
  const s2 = parseInt(document.getElementById("team2ScoreInput").value, 10);

  if (isNaN(s1) || isNaN(s2) || s1 < 0 || s2 < 0) {
    showToast("Please enter valid non-negative scores for both teams.", "danger");
    return;
  }

  const match = matches.find((m) => m.id === matchId);
  if (!match) return;

  match.score1 = s1;
  match.score2 = s2;
  match.status = "Completed";

  // Determine winner automatically based on scores
  if (s1 > s2) {
    match.winner = match.team1;
  } else if (s2 > s1) {
    match.winner = match.team2;
  } else {
    match.winner = "Draw";
  }

  saveAll();
  closeModal("scoreModal");
  renderAll();

  const winnerMsg =
    match.winner === "Draw"
      ? `Match ended in a Draw (${s1} - ${s2})!`
      : `Winner: ${match.winner} (${s1} - ${s2})!`;

  showToast(`${winnerMsg} Leaderboard recalculated automatically!`, "success");
});

// Tab Filter Buttons for Match Status
document.querySelectorAll("#matchStatusTabs .tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("#matchStatusTabs .tab-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    currentMatchStatusFilter = btn.getAttribute("data-status");
    renderMatchesTable();
  });
});

document.getElementById("filterMatchGameSelect")?.addEventListener("change", renderMatchesTable);

// ==========================================
// MODULE 3: AUTOMATED RANKING & LEADERBOARDS
// ==========================================
/**
 * Automatically computes standings based on the specified rule:
 * Win = 3 points
 * Draw = 1 point
 * Loss = 0 points
 */
function computeLeaderboard(gameFilter = "ALL") {
  // Map of team stats initialized for all known teams
  const stats = {};

  teams.forEach((t) => {
    stats[t.name] = {
      name: t.name,
      game: t.game,
      captain: t.captain,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      points: 0
    };
  });

  // Tally results from all completed matches
  matches.forEach((m) => {
    if (m.status !== "Completed") return;

    // Filter by game if requested
    if (gameFilter !== "ALL" && m.game !== gameFilter) return;

    const t1 = m.team1;
    const t2 = m.team2;

    // Initialize team record if added dynamically in matches
    if (!stats[t1]) {
      stats[t1] = { name: t1, game: m.game, captain: "-", played: 0, won: 0, drawn: 0, lost: 0, points: 0 };
    }
    if (!stats[t2]) {
      stats[t2] = { name: t2, game: m.game, captain: "-", played: 0, won: 0, drawn: 0, lost: 0, points: 0 };
    }

    stats[t1].played += 1;
    stats[t2].played += 1;

    if (m.winner === t1) {
      stats[t1].won += 1;
      stats[t1].points += 3;
      stats[t2].lost += 1;
    } else if (m.winner === t2) {
      stats[t2].won += 1;
      stats[t2].points += 3;
      stats[t1].lost += 1;
    } else if (m.winner === "Draw") {
      stats[t1].drawn += 1;
      stats[t1].points += 1;
      stats[t2].drawn += 1;
      stats[t2].points += 1;
    }
  });

  // Convert to array and filter by game if requested
  let standings = Object.values(stats);
  if (gameFilter !== "ALL") {
    standings = standings.filter((s) => s.game === gameFilter);
  }

  // Sort: Points descending, then Wins descending, then Matches Played descending
  standings.sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.won !== a.won) return b.won - a.won;
    return b.played - a.played;
  });

  return standings;
}

// Render Leaderboard & Podium
function renderLeaderboard() {
  const gameFilter = document.getElementById("filterLeaderboardGameSelect")?.value || "ALL";
  const standings = computeLeaderboard(gameFilter);

  // Render Top 3 Podium
  renderPodium(standings);

  // Render Leaderboard Table
  const tbody = document.getElementById("leaderboardTableBody");
  if (!tbody) return;

  if (standings.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="9" style="text-align:center; padding: 28px; color: var(--text-dim);">
          No teams found for the selected leaderboard filter.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = standings
    .map((team, idx) => {
      const rank = idx + 1;
      let rankBadge = `#${rank}`;
      let standingTag = "Contender";

      if (rank === 1) {
        rankBadge = `🥇 1`;
        standingTag = "🏆 Champion / Leader";
      } else if (rank === 2) {
        rankBadge = `🥈 2`;
        standingTag = "Runner-Up";
      } else if (rank === 3) {
        rankBadge = `🥉 3`;
        standingTag = "3rd Place";
      }

      return `
        <tr>
          <td><strong style="color: ${rank === 1 ? "var(--color-gold)" : rank === 2 ? "var(--color-silver)" : rank === 3 ? "var(--color-bronze)" : "#fff"}">${rankBadge}</strong></td>
          <td class="team-badge-cell">${team.name}</td>
          <td><span class="game-pill ${getGamePillClass(team.game)}">${team.game}</span></td>
          <td>${team.played}</td>
          <td style="color: var(--color-success); font-weight:700;">${team.won}</td>
          <td style="color: #cbd5e1;">${team.drawn}</td>
          <td style="color: var(--color-danger);">${team.lost}</td>
          <td><strong style="font-size: 1.25rem; color: var(--neon-blue); font-family: var(--font-heading);">${team.points} pts</strong></td>
          <td style="font-size: 0.85rem; color: var(--text-muted);">${standingTag}</td>
        </tr>
      `;
    })
    .join("");
}

// Render Podium Cards (Top 3)
function renderPodium(standings) {
  const podiumContainer = document.getElementById("podiumCards");
  if (!podiumContainer) return;

  const top3 = standings.slice(0, 3);
  const ranksConfig = [
    { rank: 1, label: "1st Place", badgeClass: "badge-gold", icon: "🥇", cardClass: "rank-1" },
    { rank: 2, label: "2nd Place", badgeClass: "badge-silver", icon: "🥈", cardClass: "rank-2" },
    { rank: 3, label: "3rd Place", badgeClass: "badge-bronze", icon: "🥉", cardClass: "rank-3" }
  ];

  podiumContainer.innerHTML = top3
    .map((team, idx) => {
      const conf = ranksConfig[idx];
      return `
        <div class="podium-card ${conf.cardClass}">
          <div class="podium-badge ${conf.badgeClass}">
            <span>${conf.icon}</span>
            <span>${conf.label}</span>
          </div>
          <h4 class="podium-team-name">${team.name}</h4>
          <div class="podium-game">${team.game} • Captain: ${team.captain || "-"}</div>
          <div class="podium-score-row">
            <div class="podium-stat">
              <strong>${team.points}</strong>
              <span>Points</span>
            </div>
            <div class="podium-stat">
              <strong>${team.won}</strong>
              <span>Wins</span>
            </div>
            <div class="podium-stat">
              <strong>${team.played}</strong>
              <span>Played</span>
            </div>
          </div>
        </div>
      `;
    })
    .join("");
}

document.getElementById("filterLeaderboardGameSelect")?.addEventListener("change", renderLeaderboard);

// ==========================================
// MODAL CONTROLS & EVENT LISTENERS
// ==========================================
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  modal.classList.add("active");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return;
  modal.classList.remove("active");
  modal.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}

window.closeModal = closeModal;

// Close modals on clicking overlay backdrop
document.querySelectorAll(".modal-overlay").forEach((overlay) => {
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) {
      closeModal(overlay.id);
    }
  });
});

// Close modals on Escape key
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    document.querySelectorAll(".modal-overlay.active").forEach((m) => closeModal(m.id));
  }
});

// Reset Data Button with confirmation
document.getElementById("resetDataBtn")?.addEventListener("click", () => {
  if (confirm("Reset all teams, matches, and leaderboard data back to initial sample state?")) {
    resetToDefaultData(true);
  }
});

// Mobile menu toggle
const mobileBtn = document.getElementById("mobileMenuBtn");
const navLinks = document.getElementById("navLinks");
if (mobileBtn && navLinks) {
  mobileBtn.addEventListener("click", () => {
    navLinks.classList.toggle("active");
  });
  navLinks.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => navLinks.classList.remove("active"));
  });
}

// Active navigation highlight on scroll
window.addEventListener("scroll", () => {
  const sections = document.querySelectorAll("section[id]");
  const scrollY = window.pageYOffset;

  sections.forEach((section) => {
    const sectionHeight = section.offsetHeight;
    const sectionTop = section.offsetTop - 100;
    const sectionId = section.getAttribute("id");
    const correspondingLink = document.querySelector(`.nav-link[href="#${sectionId}"]`);

    if (correspondingLink) {
      if (scrollY >= sectionTop && scrollY < sectionTop + sectionHeight) {
        correspondingLink.classList.add("active");
      } else {
        correspondingLink.classList.remove("active");
      }
    }
  });
});

// On Page Load: Initialize and render
document.addEventListener("DOMContentLoaded", () => {
  initData();
});
